<?php

/**
 * Plugin Name: Job Portal
 * Plugin URI: https://www.mirumagency.com/
 * Description: Plugin for Job Posting System
 * Version: 1.0
 * Author: Sanad Qazi
 * Author URI: https://mirumagency.com/
 **/

// Define path
define('JOB_PORTAL_PATH', plugin_dir_path(__FILE__));

// Include required files
require_once(JOB_PORTAL_PATH . 'inc/register-custom-post-type.php');
require_once(JOB_PORTAL_PATH . 'inc/register-submenu.php');
require_once(JOB_PORTAL_PATH . 'inc/applicant-entries-page.php');
require_once(JOB_PORTAL_PATH . 'inc/activation-task.php');
require_once(JOB_PORTAL_PATH . 'inc/register-custom-taxonomies.php');
require_once(JOB_PORTAL_PATH . 'inc/add-custom-filters.php');


//Activation hook
if (!function_exists('plugin_activation_jobs')) {
    function plugin_activation_jobs()
    {
        // Perform activation tasks
        activate_create_table();
    }
    register_activation_hook(__FILE__, 'plugin_activation_jobs');
}
