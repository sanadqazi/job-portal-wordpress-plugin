<?php
// Register Submenu

if (!function_exists('applicant_entries_page')) {
    function applicant_entries_page()
    {
        add_submenu_page(
            'edit.php?post_type=job',
            __('Job Applications'),
            __('Job Applications'),
            'manage_options',
            'view-entries',
            'applicant_entries_page_callback'
        );
    }
    add_action('admin_menu', 'applicant_entries_page');
}
