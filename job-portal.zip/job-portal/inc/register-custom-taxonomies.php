<?php
// Register custom taxonomies

if (!function_exists('add_custom_taxonomies')) {
    function add_custom_taxonomies()
    {
        // Register Location Taxonomy
        register_taxonomy('location', 'job', array(

            'hierarchical' => true,
            'labels' => array(
                'name' => _x('Locations', 'taxonomy general name'),
                'singular_name' => _x('Location', 'taxonomy singular name'),
                'search_items' =>  __('Search Locations'),
                'all_items' => __('All Locations'),
                'parent_item' => __('Parent Location'),
                'parent_item_colon' => __('Parent Location:'),
                'edit_item' => __('Edit Location'),
                'update_item' => __('Update Location'),
                'add_new_item' => __('Add New Location'),
                'new_item_name' => __('New Location Name'),
                'menu_name' => __('Locations'),
            ),
            // Control the slugs used for this taxonomy
            'rewrite' => array(
                'slug' => 'job_locations',
                'with_front' => false,
                'hierarchical' => true
            ),
        ));

        //Register Department Taxonomy
        register_taxonomy('department', 'job', array(

            'hierarchical' => true,
            'labels' => array(
                'name' => _x('Departments', 'taxonomy general name'),
                'singular_name' => _x('Department', 'taxonomy singular name'),
                'search_items' =>  __('Search Departments'),
                'all_items' => __('All Departments'),
                'parent_item' => __('Parent Department'),
                'parent_item_colon' => __('Parent Department:'),
                'edit_item' => __('Edit Department'),
                'update_item' => __('Update Department'),
                'add_new_item' => __('Add New Department'),
                'new_item_name' => __('New Department Name'),
                'menu_name' => __('Departments'),
            ),
            // Control the slugs used for this taxonomy
            'rewrite' => array(
                'slug' => 'job_department',
                'with_front' => false,
                'hierarchical' => true
            ),
        ));
    }
}
add_action('init', 'add_custom_taxonomies', 0);
