<?php

// Register custom post type function
if (!function_exists('register_job_posting')) {
    function register_job_posting()
    {

        $labels = array(
            'name'                => _x('Jobs', 'Post Type General Name'),
            'singular_name'       => _x('Job', 'Post Type Singular Name'),
            'menu_name'           => __('Jobs'),
            'parent_item_colon'   => __('Parent  Job'),
            'all_items'           => __('All Jobs'),
            'view_item'           => __('View Job'),
            'add_new_item'        => __('Add New Job'),
            'add_new'             => __('Add New'),
            'edit_item'           => __('Edit Job'),
            'update_item'         => __('Update Job'),
            'search_items'        => __('Search Job'),
            'not_found'           => __('Not Found'),
            'not_found_in_trash'  => __('Not found in Trash'),
        );

        $args = array(
            'label'               => __('Jobs'),
            'labels'              => $labels,
            'supports'            => array('title', 'editor', 'thumbnail', 'revisions'),
            'taxonomies'          => array('jobs'),
            'hierarchical'        => false,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'            => 'dashicons-groups',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'post',
            'show_in_rest' => true

        );
        register_post_type('job', $args);
    }
    // Hooking up our function to theme setup
    add_action('init', 'register_job_posting');
}
