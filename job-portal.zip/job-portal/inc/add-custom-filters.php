<?php

// Count of posts present in department taxonomy
function department_count()
{
    $dept_count = wp_count_terms([
        'taxonomy'   => 'department',
        'hide_empty' => true
    ]);
    return $dept_count;
}

// Count of posts present in location taxonomy
function location_count()
{
    $location_count = wp_count_terms([
        'taxonomy'   => 'location',
        'hide_empty' => true
    ]);
    return $location_count;
}

// Location: Display a custom taxonomy dropdown in admin
if (!function_exists('filter_post_type_by_taxonomy_location')) {
    function filter_post_type_by_taxonomy_location()
    {
        global $typenow;
        $post_type = 'job';
        $taxonomy  = 'location';
        if ($typenow == $post_type) {
            $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
            $info_taxonomy = get_taxonomy($taxonomy);
            if (location_count() !== '0') {
                wp_dropdown_categories(array(
                    'show_option_all' => sprintf(__('Show all %s'), $info_taxonomy->label),
                    'taxonomy'        => $taxonomy,
                    'name'            => $taxonomy,
                    'orderby'         => 'name',
                    'selected'        => $selected,
                    'show_count'      => true,
                    'hide_empty'      => true,
                ));
            }
        }
    }
}
add_action('restrict_manage_posts', 'filter_post_type_by_taxonomy_location');


// Location: Filter posts by taxonomy in admin

if (!function_exists('convert_id_to_term_in_query_location')) {
    function convert_id_to_term_in_query_location($query)
    {
        global $pagenow;
        $post_type = 'job';
        $taxonomy  = 'location';
        $q_vars    = &$query->query_vars;
        if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0) {
            $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
            $q_vars[$taxonomy] = $term->slug;
        }
    }
}
add_filter('parse_query', 'convert_id_to_term_in_query_location');


// Department: Display a custom taxonomy dropdown in admin

if (!function_exists('filter_post_type_by_taxonomy_department')) {
    function filter_post_type_by_taxonomy_department()
    {

        global $typenow;
        $post_type = 'job';
        $taxonomy  = 'department';
        if ($typenow == $post_type) {
            $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
            $info_taxonomy = get_taxonomy($taxonomy);
            if (department_count() !== '0') {
                wp_dropdown_categories(array(
                    'show_option_all' => sprintf(__('Show all %s'), $info_taxonomy->label),
                    'taxonomy'        => $taxonomy,
                    'name'            => $taxonomy,
                    'orderby'         => 'name',
                    'selected'        => $selected,
                    'show_count'      => true,
                    'hide_empty'      => true,
                ));
            }
        }
    }
}

add_action('restrict_manage_posts', 'filter_post_type_by_taxonomy_department');



// Department: Filter posts by taxonomy in admin

if (!function_exists('convert_id_to_term_in_query_department')) {
    function convert_id_to_term_in_query_department($query)
    {
        global $pagenow;
        $post_type = 'job';
        $taxonomy  = 'department';
        $q_vars    = &$query->query_vars;
        if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0) {
            $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
            $q_vars[$taxonomy] = $term->slug;
        }
    }
}

add_filter('parse_query', 'convert_id_to_term_in_query_department');
