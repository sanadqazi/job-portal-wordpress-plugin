<?php
// Initialize DB Tables
if (!function_exists('activate_create_table')) {
    function activate_create_table()
    {

        // WP Globals
        global $table_prefix, $wpdb;

        // Entries Table
        $entriesTable = $table_prefix . 'job_entries';

        // Create Entries Table if not exist
        if ($wpdb->get_var("show tables like '$entriesTable'") != $entriesTable) {

            // Query - Create Table
            $sql = "CREATE TABLE `$entriesTable` (";
            $sql .= "   `id` int(11) NOT NULL AUTO_INCREMENT,
        `full_name` varchar(255) NOT NULL,
        `age` int(11) NOT NULL,
        `email` varchar(255) NOT NULL,
        `address` varchar(255) NOT NULL,
        `contact` varchar(255) NOT NULL,
        `job_id` int(11) NOT NULL,
        `resume_file` varchar(255) NOT NULL,
        `applied_on` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
      
      INSERT INTO `$entriesTable` (`id`, `full_name`, `age`, `email`, `address`, `contact`, `job_id`, `resume_file`, `applied_on`) VALUES
      (1,	'Demo user 1',	25,	'demo@gmail.com',	'demo user data from database',	'9988776655',	1,	'resume.pdf',	'2023-05-31 15:15:39')";

            // Include Upgrade Script
            require_once(ABSPATH . '/wp-admin/includes/upgrade.php');

            // Create Table
            dbDelta($sql);
        }
    }
}
