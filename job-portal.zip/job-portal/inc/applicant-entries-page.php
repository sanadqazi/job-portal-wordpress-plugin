<?php

// Display callback for the submenu page.
if (!function_exists('applicant_entries_page_callback')) {
    function applicant_entries_page_callback()
    {
        // WP Globals
        global $table_prefix, $wpdb;

        // Entries Table
        $entriesTable = $table_prefix . 'job_entries';

        // Fetch all applications entries
        $data = $wpdb->get_results("SELECT * FROM $entriesTable");
?>
        <div class="wrap">
            <h1 class="wp-heading-inline">
                Applicant Entries</h1>
            <table class="widefat fixed" cellspacing="0">
                <thead>
                    <tr>

                        <th id="name" class="manage-column" scope="col">Name</th>
                        <th id="age" class="manage-column age" scope="col">Age</th>
                        <th id="email" class="manage-column email" scope="col">Email</th>
                        <th id="address" class="manage-column address" scope="col">Address</th>
                        <th id="contact" class="manage-column contact" scope="col">Contact</th>
                        <th id="job" class="manage-column job" scope="col">Job</th>
                        <th id="download" class="manage-column download" scope="col">Download CV</th>
                        <th id="date" class="manage-column date" scope="col">Applied on</th>

                    </tr>
                </thead>

                <tfoot>
                    <tr>

                        <th id="name" class="manage-column" scope="col">Name</th>
                        <th id="age" class="manage-column age" scope="col">Age</th>
                        <th id="email" class="manage-column email" scope="col">Email</th>
                        <th id="address" class="manage-column address" scope="col">Address</th>
                        <th id="contact" class="manage-column contact" scope="col">Contact</th>
                        <th id="job" class="manage-column job" scope="col">Job</th>
                        <th id="download" class="manage-column download" scope="col">Download CV</th>
                        <th id="date" class="manage-column date" scope="col">Applied on</th>

                    </tr>
                </tfoot>

                <tbody>
                    <tr class="alternate">
                        <?php foreach ($data as $data) {
                            echo '<td class="column-columnname">' . $data->full_name . '</td>';
                            echo '<td class="column-columnname">' . $data->age . '</td>';
                            echo '<td class="column-columnname">' . $data->email . '</td>';
                            echo '<td class="column-columnname">' . $data->address . '</td>';
                            echo '<td class="column-columnname">' . $data->contact . '</td>';
                            if ($data->job_id == 1) {
                                $job_name = "Demo Job 1";
                            }
                            echo '<td class="column-columnname">' . $job_name . '</td>';
                            echo '<td class="column-columnname"><a target="_blank" href="' . site_url() . '/wp-content/plugins/job-portal/test-data/' . $data->resume_file . '">' . $data->resume_file . '</a></td>';
                            echo '<td class="column-columnname">' . $data->applied_on . '</td>';
                        } ?>

                    </tr>
                </tbody>
            </table>
        </div>
<?php
    }
}
